package model;

/**
 * this class creatures a Rattata
 */
public class CreatureRattata extends Creature {
	
	public CreatureRattata() {
		super("Rattata", "pics/rattata.png", 20, 10, 12);
	}

}
