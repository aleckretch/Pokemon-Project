package model;

/**
 * this class creatures a Mankey
 */
public class CreatureMankey extends Creature {
	
	public CreatureMankey() {
		super("Mankey", "pics/mankey.png", 45, 40, 5);
	}

}
