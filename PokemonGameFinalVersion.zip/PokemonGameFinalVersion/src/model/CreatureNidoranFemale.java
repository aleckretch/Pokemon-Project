package model;

/**
 * this class creatures a Nidoran (f)
 */
public class CreatureNidoranFemale extends Creature {
	
	public CreatureNidoranFemale() {
		super("Nidoran (f)", "pics/nidoranf.png", 65, 30, 8);
	}

}
