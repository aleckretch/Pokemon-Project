package model;

/**
 * this class creatures a Clefable
 */
public class CreatureClefable extends Creature {
	
	public CreatureClefable() {
		super("Clefable", "pics/clefable.png", 52, 50, 6);
	}

}
