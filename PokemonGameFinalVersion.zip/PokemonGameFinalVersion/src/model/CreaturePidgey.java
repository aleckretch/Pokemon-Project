package model;

/**
 * this class creatures a Pidgey
 */
public class CreaturePidgey extends Creature{

	public CreaturePidgey() {
		super("Pidgey", "pics/pidgey.png", 35, 15, 8);
	}

}
