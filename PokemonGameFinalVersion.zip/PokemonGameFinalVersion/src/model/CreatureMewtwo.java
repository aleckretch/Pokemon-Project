package model;

/**
 * this class creatures a Mewtwo
 */
public class CreatureMewtwo extends Creature {
	
	public CreatureMewtwo() {
		super("Mewtwo", "pics/mewtwo.png", 100, 50, 6);
	}

}
