package model;


/**
 * this class creatures a Ekans
 */
public class CreatureEkans extends Creature {
	
	public CreatureEkans() {
		super("Ekans", "pics/ekans.png", 30, 10, 20);
	}

}
