package model;

/**
 * this class creatures a Pikachu
 */
public class CreaturePikachu extends Creature {
	
	public CreaturePikachu () {
		super("Pikachu", "pics/pikachu.png", 60, 40, 4);
	}

}
