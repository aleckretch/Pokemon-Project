package model;

/**
 * this class creatures a Nidoran (m)
 */
public class CreatureNidoranMale extends Creature {
	
	public CreatureNidoranMale() {
		super("Nidoran (m)", "pics/nidoranm.png", 75, 20, 10);
	}

}
