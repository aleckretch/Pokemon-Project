package model;

/**
 * this class creatures a Beedrill
 */
public class CreatureBeedrill extends Creature {
	
	public CreatureBeedrill() {
		super("Beedrill", "pics/beedrill.png", 70, 40, 5);
	}

}
